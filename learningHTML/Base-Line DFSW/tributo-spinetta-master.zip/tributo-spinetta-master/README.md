# Página tributo a Luis Alberto Spinetta

### [Live Demo](https://guido732.github.io/tributo-spinetta/)

Página tributo a Spinetta. Ejercicio de la carrera de Desarrollo Web Full Stack de Acámica.
La idea era probar y experimentar con distintas funciones y propiedades a modo de ejercicio de CSS utilizando SASS/SCSS como preprocesador.

-----

Tribute page for Spinetta. Excercise for the DWFS Career at Acámica. 
The goal was to test and experiment with diverse properties and functionality in CSS while using SASS/SCSS as a preprocessor.
