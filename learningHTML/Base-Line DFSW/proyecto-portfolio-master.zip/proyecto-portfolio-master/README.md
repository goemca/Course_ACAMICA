# Sitio web proyecto Página Portfolio Personal

### [Live Demo](https://guido732.github.io/proyecto-portfolio/)

Proyecto corto página portfolio personal con trabajos de Desarrollo Web

## Recursos y tecnologías utilizadas

-   HTML5
-   CSS3 - SASS/SCSS
-   FontAwesome
-   Google Fonts
-   Git para control de versiones

El objetivo era crear una landing page con trabajos propios de desarrollo web a modo de portfolio personal.

----

Short project, a personal portfolio landing page.

## Resources and technologies used:

-   HTML5
-   CSS3 - SASS/SCSS
-   FontAwesome Icons
-   Google Fonts
-   Git for version control

The goal was to make a landing page with personal projects as a personal portfolio for web devlopment. 
