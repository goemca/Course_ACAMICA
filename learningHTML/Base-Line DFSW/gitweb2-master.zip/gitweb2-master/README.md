# GITWEB - Portfolio Online

### [LIVE DEMO](https://guido732.github.io/gitweb2/)

Página de portfolio personal para mis trabajos de Desarrollo Web Frontend y otros.

Hecha con:

-   HTML / CSS (vanilla)
-   Bootstrap
-   Js
-   Isotope.js

Diseño y desarrollo hecho por mí

Estructura y diseño de uso libre para cualquiera que le pueda interesar para mostrar sus proyectos.
